package com.company;
import java.util.Scanner;

public class Main {
    static Scanner sc = new Scanner(System.in);

    public static void main(String[] args) {

        Calculadora calculadora = new Calculadora();

        System.out.println("MENU - CALCULADORA" +
                "\n1 - Soma" +
                "\n2 - Multiplicação" +
                "\n3 - Divisão" +
                "\n4 - Subtração" +
                "\n5 - Potenciação" +
                "\n6 - Porcentagem" +
                "\n7 - Raiz quadrada");
        int opcao = sc.nextInt();
	    switch (opcao){
            case 1:
                System.out.println( calculadora.soma());
                break;
            case 2:
                System.out.println(calculadora.multiplicacao());
                break;
            case 3:
                System.out.println(calculadora.divisao());
                break;
            case 4:
                System.out.println(calculadora.subtracao());
                break;
            case 5:
                System.out.println(calculadora.potenciacao());
                break;
            case 6:
                System.out.println( calculadora.porcentagem());
                break;
            case 7:
                System.out.println(calculadora.raizQuadrada());
                break;
        }

    }


}
