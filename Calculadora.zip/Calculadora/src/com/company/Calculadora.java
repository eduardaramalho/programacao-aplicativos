package com.company;

import java.util.Scanner;

public class Calculadora {
    static Scanner sc = new Scanner(System.in);
    private double num1;
    private double num2;

    public static void menu(){
        System.out.println("NUM 01:");
        double num1 = sc.nextDouble();
        System.out.println("NUM 02:");
        double num2 = sc.nextDouble();
    }


    public double soma() {
        System.out.println("NUM 01:");
        double num1 = sc.nextDouble();
        System.out.println("NUM 02:");
        double num2 = sc.nextDouble();
        return num1 + num2;
    }

    public double subtracao(){
        System.out.println("NUM 01:");
        double num1 = sc.nextDouble();
        System.out.println("NUM 02:");
        double num2 = sc.nextDouble();
        return num1 - num2;
    }

    public static double multiplicacao(){
        System.out.println("NUM 01:");
        double num1 = sc.nextDouble();
        System.out.println("NUM 02:");
        double num2 = sc.nextDouble();
        return num1 * num2;
    }

    public static double divisao(){
        System.out.println("NUM 01:");
        double num1 = sc.nextDouble();
        System.out.println("NUM 02:");
        double num2 = sc.nextDouble();
        return num1/num2;
    }


    public static double potenciacao(){
        System.out.println("NUM 01:");
        double num1 = sc.nextDouble();
        System.out.println("NUM 02:");
        double num2 = sc.nextDouble();
        return Math.pow(num1, num2);
    }

    public static double porcentagem(){
        System.out.println("NUM 01:");
        double num1 = sc.nextDouble();
        System.out.println("NUM 02:");
        double num2 = sc.nextDouble();
        return Math.pow(num1, num2);
    }

    public static double raizQuadrada(){
        System.out.println("NUM 01:");
        double num1 = sc.nextDouble();
        return Math.sqrt(num1);
    }

}
